# PixelGram - Spring 2021 ADS Project
Authors:
1. [Suraj Gupta Gudla](https://github.com/surajgupta-git)
2. [Sravya Garaga](https://github.com/sravya160597)
3. [Sai Prudvi krishna Sannidhi](https://github.com/sannidhi09)

![Goals and Actions](https://user-images.githubusercontent.com/29830913/106647414-e5b25b80-655c-11eb-8c96-d008511033bf.jpg)
# Napkin Diagram
![Napkin diagram](https://user-images.githubusercontent.com/66148226/106688289-d0105680-659b-11eb-9f1e-f5432a3ad4e2.jpg)
# Overview:
Having access to a camera 24/7 has its benefits. Everything can be captured. The downside is, how can we store all these images and share them? Our photo sharing application "PixelGram" makes it the best way to store photos online when you use multiple devices to photograph. PixelGram allows bulk upload of images as well as supports automatic photo backup from various devices. The users can log in through their Google, IU, or GitHub credentials. This app allows the users to organize their photos into albums/folders and also tag their images with names and locations for searchability ease. The images stored by the user will be grouped on a timeline. The users can further share the images or albums privately or with a group of individuals. The photos are stored in the cloud and can be retrieved from offline systems as and when required. With PixelGram It's easier, safer, and quicker to efficiently store & share your captured moments online.

